"use client";

/**
 * Replicate a campaign into new cities.
 *
 * Three steps: pick the source, name the cities, review. Everything else is
 * lifted from the source, so the only things typed are city names.
 *
 * The gates still run per city and a blocked city is skipped rather than
 * silently created — replication saves typing, not checks.
 */

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useFetch } from "@/lib/useFetch";
import { inr, num, cn } from "@/lib/format";
import {
  AlertTriangle,
  ArrowRight,
  Check,
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  Copy,
  Plus,
  Send,
  X,
} from "lucide-react";
import { buildReplicationPlan, type ReplicationSource } from "@/lib/engine/replicate";
import type { AdSetSettings } from "@/lib/engine/classify";

const STEPS = ["Source", "Cities", "Review"];

interface Ctx {
  sources: ReplicationSource[];
  catalogues: { catalogueId: string; name: string; vertical: "vehicles" | "commerce"; inUse: boolean }[];
  productSets: {
    productSetId: string;
    catalogueId: string;
    name: string;
    productCount: number;
    filterRule: string;
    cityKey: string | null;
  }[];
  defaultCatalogueId: string;
  knownCities: { name: string; state: string; tier: string }[];
  existingCityNames: string[];
  adSetSettings: AdSetSettings[];
}

export default function ReplicatePage() {
  const router = useRouter();
  const { data: ctx } = useFetch<Ctx>("/api/replicate");

  const [step, setStep] = useState(0);
  const [sourceId, setSourceId] = useState("");
  const [cityInput, setCityInput] = useState("");
  const [cityNames, setCityNames] = useState<string[]>([]);
  const [manualStates, setManualStates] = useState<Record<string, string>>({});
  // Product sets the operator creates in Commerce Manager while working through
  // the batch. Without this, every genuinely new city blocks with no way out.
  const [manualSets, setManualSets] = useState<Record<string, { productSetId: string; name: string; productCount: number }>>({});
  const [budgetOverride, setBudgetOverride] = useState<number | null>(null);
  const [ceilingOverride, setCeilingOverride] = useState<number | null>(null);
  // The raw text, kept separately so the field can be emptied mid-edit without
  // the value collapsing to 0 under the operator.
  const [budgetRaw, setBudgetRaw] = useState("");
  const [ceilingRaw, setCeilingRaw] = useState("");
  const [pixelVerified, setPixelVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [creatingSet, setCreatingSet] = useState<string | null>(null);
  const [setErrors, setSetErrors] = useState<Record<string, string>>({});

  /**
   * Create the missing product set in the catalogue and record it, so a blocked
   * city can be unblocked without leaving the screen. The vehicle count comes
   * back from Meta rather than being assumed — a set matching eleven cars is
   * something to see before launching, not after.
   */
  async function createProductSet(cityName: string) {
    const key = cityName.toLowerCase();
    setCreatingSet(cityName);
    setSetErrors({ ...setErrors, [key]: "" });
    try {
      const r = await fetch("/api/product-set", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cityName }),
      });
      const j = (await r.json()) as {
        productSetId?: string;
        name?: string;
        productCount?: number;
        error?: string;
        filterRule?: string;
      };
      if (!r.ok || !j.productSetId) {
        setSetErrors({
          ...setErrors,
          [key]: j.error ?? "Could not create the product set.",
        });
        return;
      }
      setManualSets({
        ...manualSets,
        [key]: {
          productSetId: j.productSetId,
          name: j.name ?? `${cityName} Catalogue`,
          productCount: j.productCount ?? 0,
        },
      });
    } catch (e) {
      setSetErrors({ ...setErrors, [key]: e instanceof Error ? e.message : String(e) });
    } finally {
      setCreatingSet(null);
    }
  }
  const [result, setResult] = useState<any>(null);

  const source = ctx?.sources.find((s) => s.campaignId === sourceId) ?? null;
  const dailyBudget = budgetOverride ?? source?.dailyBudget ?? 0;
  const ceiling = ceilingOverride ?? source?.targetCpl ?? 0;

  const catalogue = useMemo(() => {
    if (!ctx) return null;
    const id = source?.catalogueId ?? ctx.defaultCatalogueId;
    const c = ctx.catalogues.find((x) => x.catalogueId === id);
    return c ? { catalogueId: c.catalogueId, catalogueName: c.name, vertical: c.vertical, inUse: c.inUse } : null;
  }, [ctx, source?.catalogueId]);

  const plan = useMemo(() => {
    if (!ctx || !source || cityNames.length === 0) return null;
    return buildReplicationPlan({
      source,
      cityNames,
      dailyBudget,
      cplCeiling: ceiling,
      pixelVerified,
      existingCityNames: ctx.existingCityNames,
      existingAdSets: ctx.adSetSettings,
      catalogue,
      productSets: ctx.productSets,
      manualStates,
      manualProductSets: manualSets,
    });
  }, [ctx, source, cityNames, dailyBudget, ceiling, pixelVerified, catalogue, manualStates, manualSets]);

  /**
   * Cities already in the platform used to be filtered out of this list
   * entirely. Typing "Mohali" then returned nothing, which reads as "we don't
   * know that city" rather than "you already run it" — and left no way to see
   * why. They are shown now, labelled, and only the ones already added to this
   * batch are hidden.
   */
  const suggestions = useMemo(() => {
    if (!ctx || !cityInput.trim()) return [];
    const q = cityInput.trim().toLowerCase();
    const inBatch = new Set(cityNames.map((c) => c.toLowerCase()));
    const running = new Set(ctx.existingCityNames.map((c) => c.toLowerCase()));
    return ctx.knownCities
      .filter((c) => c.name.toLowerCase().includes(q) && !inBatch.has(c.name.toLowerCase()))
      .map((c) => ({ ...c, alreadyRunning: running.has(c.name.toLowerCase()) }))
      // Cities you don't yet run are the ones you're usually after, so they
      // sort first rather than being buried under the ones you do.
      .sort((a, b) => Number(a.alreadyRunning) - Number(b.alreadyRunning))
      .slice(0, 6);
  }, [ctx, cityInput, cityNames, ctx?.existingCityNames]);

  function addCity(name: string) {
    const n = name.trim();
    if (!n || cityNames.some((c) => c.toLowerCase() === n.toLowerCase())) return;
    setCityNames([...cityNames, n]);
    setCityInput("");
  }

  async function run() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/replicate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceCampaignId: sourceId,
          cityNames: plan?.launchable.map((t) => t.cityName) ?? [],
          dailyBudget,
          cplCeiling: ceiling,
          pixelVerified,
          catalogueId: catalogue?.catalogueId,
          manualStates,
          manualProductSets: manualSets,
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error ?? "Replication failed.");
        setBusy(false);
        return;
      }
      setResult(json);
    } catch {
      setError("Replication failed — could not reach the server.");
    }
    setBusy(false);
  }

  // ------------------------------------------------------------------ done
  if (result) {
    return (
      <div className="max-w-3xl">
        {/* This screen used to say "launched", which reads as "live in Meta".
            Replicate only writes to this platform — nothing here has touched
            the ad account. Saying so is the whole point of the panel. */}
        <div className="rounded-2xl border border-positive/30 bg-positive/5 p-6 mb-4">
          <div className="flex items-center gap-2 text-positive font-semibold mb-1">
            <Check className="h-5 w-5" /> {result.created.length}{" "}
            {result.created.length === 1 ? "city" : "cities"} prepared from {result.source.name}
          </div>
          <p className="text-sm text-ink-600 dark:text-ink-300">
            {inr(result.totalDailyBudget)}/day planned across the batch.
          </p>
        </div>

        <div className="rounded-2xl border border-caution/40 bg-caution/5 p-5 mb-6">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="h-4 w-4 text-caution mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold text-sm text-ink-900 dark:text-ink-50">
                Not created in Meta — these exist only in this platform
              </p>
              <p className="text-xs text-ink-600 dark:text-ink-300 mt-1">
                Replicate builds the plan: the settings, the per-city product set, the budget and the gates.
                Nothing has been sent to Ads Manager, so you will not find these campaigns there yet. Publish
                each city to create it for real.
              </p>
              <div className="flex flex-wrap gap-2 mt-3">
                {result.created.map((c: any) => (
                  <button
                    key={c.campaignId}
                    className="btn-secondary btn-sm !text-xs"
                    onClick={() =>
                      router.push(
                        `/campaigns/publish?city=${encodeURIComponent(c.cityName)}&source=${encodeURIComponent(
                          result.source.campaignId
                        )}`
                      )
                    }
                  >
                    <Send className="h-3.5 w-3.5" /> Publish {c.cityName} to Meta
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-ink-200 dark:border-ink-800 overflow-hidden mb-6">
          {result.created.map((c: any) => (
            <div key={c.campaignId} className="p-4 border-b border-ink-200 dark:border-ink-800 last:border-0">
              <p className="font-semibold text-ink-900 dark:text-ink-50">{c.cityName}</p>
              <p className="text-xs font-mono text-ink-500 mt-0.5">{c.campaignName}</p>
              <div className="mt-2 space-y-1">
                {c.adSets.map((a: any) => (
                  <p key={a.id} className="text-xs text-ink-600 dark:text-ink-300">
                    {a.name}
                    {a.productSetName ? ` · ${a.productSetName} (${num(a.productCount)} vehicles)` : ""}
                  </p>
                ))}
              </div>
              <p className="text-xs text-ink-500 mt-2">
                Create audience <span className="font-mono">{c.pvAudience}</span>
              </p>
            </div>
          ))}
        </div>

        {result.skipped?.length > 0 && (
          <div className="rounded-xl border border-caution/40 bg-caution/5 p-4 mb-6">
            <p className="text-sm font-semibold text-ink-900 dark:text-ink-50 mb-2">
              {result.skipped.length} skipped
            </p>
            {result.skipped.map((s: any) => (
              <p key={s.cityName} className="text-xs text-ink-600 dark:text-ink-300">
                <span className="font-semibold">{s.cityName}</span> — {s.reason}
              </p>
            ))}
          </div>
        )}

        <button onClick={() => router.push("/campaigns")} className="btn-primary">
          View campaigns <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    );
  }

  // ---------------------------------------------------------------- wizard
  return (
    <div className="max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-extrabold text-ink-900 dark:text-ink-50">Replicate a campaign</h1>
        <p className="text-sm text-ink-500 mt-0.5">
          Takes every setting from an existing campaign. You name the cities; the state, product set and geo are
          resolved per city.
        </p>
      </div>

      <ol className="flex items-center gap-1 mb-6">
        {STEPS.map((s, i) => (
          <li key={s} className="flex items-center gap-1">
            <span
              className={cn(
                "text-xs font-semibold px-2.5 py-1 rounded-md",
                i === step
                  ? "bg-brand-600 text-white"
                  : i < step
                  ? "bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300"
                  : "text-ink-400"
              )}
            >
              {s}
            </span>
            {i < STEPS.length - 1 && <ChevronRight className="h-3 w-3 text-ink-300" />}
          </li>
        ))}
      </ol>

      <div className="rounded-2xl border border-ink-200 dark:border-ink-800 bg-white dark:bg-ink-950 p-6 shadow-card">
        {/* ------------------------------------------------ 0. Source */}
        {step === 0 && (
          <div>
            <h2 className="font-bold text-ink-900 dark:text-ink-50 mb-1">Which campaign?</h2>
            <p className="text-sm text-ink-500 mb-4">
              Its ad set structure, targeting, budget and ceiling become the template. Geo and the product set are the
              two things replaced per city.
            </p>
            <div className="space-y-2">
              {ctx?.sources.map((s) => (
                <button
                  key={s.campaignId}
                  onClick={() => setSourceId(s.campaignId)}
                  className={cn(
                    "w-full text-left p-4 rounded-xl border",
                    sourceId === s.campaignId
                      ? "border-brand-600 bg-brand-50 dark:bg-brand-950"
                      : "border-ink-200 dark:border-ink-800"
                  )}
                >
                  <p className="font-semibold text-sm text-ink-900 dark:text-ink-50">{s.name}</p>
                  <p className="text-xs text-ink-500 mt-0.5">
                    {s.cities.join(", ") || "no city"} · {s.adSets.length} ad set
                    {s.adSets.length === 1 ? "" : "s"} ({s.adSets.map((a) => a.kind.toLowerCase()).join(", ")}) ·{" "}
                    {inr(s.dailyBudget)}/day · ceiling {inr(s.targetCpl)}
                  </p>
                  <p className="text-xs font-mono text-ink-400 mt-0.5">
                    {s.resultType} · {s.attributionSetting}
                    {s.catalogueName ? ` · ${s.catalogueName}` : " · no catalogue"}
                  </p>
                  {s.cautions.length > 0 && sourceId === s.campaignId && (
                    <div className="mt-2 space-y-1">
                      {s.cautions.map((c) => (
                        <p key={c} className="text-xs text-caution flex items-start gap-1.5">
                          <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                          {c}
                        </p>
                      ))}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ------------------------------------------------ 1. Cities */}
        {step === 1 && source && (
          <div>
            <h2 className="font-bold text-ink-900 dark:text-ink-50 mb-1">Which cities?</h2>
            <p className="text-sm text-ink-500 mb-4">
              Type a city and press Enter. The state fills in automatically, and the product set is matched from{" "}
              {catalogue?.catalogueName ?? "the catalogue"} by the city filter.
            </p>

            <div className="relative mb-3">
              <input
                className="input"
                value={cityInput}
                onChange={(e) => setCityInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addCity(suggestions[0]?.name ?? cityInput);
                  }
                }}
                placeholder="Lucknow, Jaipur, Indore…"
              />
              {suggestions.length > 0 && (
                <div className="absolute z-10 left-0 right-0 mt-1 rounded-xl border border-ink-200 dark:border-ink-800 bg-white dark:bg-ink-950 shadow-card overflow-hidden">
                  {suggestions.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => addCity(c.name)}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-ink-50 dark:hover:bg-ink-900 flex items-center justify-between"
                    >
                      <span className="text-ink-900 dark:text-ink-50">
                        {c.name}
                        {c.alreadyRunning && (
                          <span className="ml-2 text-xs font-normal text-caution">already running</span>
                        )}
                      </span>
                      <span className="text-xs text-ink-500">{c.state}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {plan && (
              <div className="space-y-2 mb-4">
                {plan.targets.map((t) => {
                  const blocking = t.plan.gates.filter((g) => g.status === "BLOCK");
                  return (
                    <div
                      key={t.cityName}
                      data-city={t.cityName}
                      className={cn(
                        "p-3.5 rounded-xl border",
                        t.alreadyExists || blocking.length > 0
                          ? "border-negative/40 bg-negative/5"
                          : "border-ink-200 dark:border-ink-800"
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="font-semibold text-sm text-ink-900 dark:text-ink-50">
                            {t.cityName}
                            <span className="ml-2 text-xs font-normal text-ink-500">{t.state ?? "state unknown"}</span>
                          </p>
                          <p className="text-xs text-ink-500 mt-0.5">
                            {t.productSet
                              ? `${t.productSet.name} · ${num(t.productSet.productCount)} vehicles`
                              : `No product set — create one filtered on ${t.expectedFilterRule}`}
                          </p>
                          {t.alreadyExists && (
                            <p className="text-xs text-negative mt-1">Already in the platform — will be skipped.</p>
                          )}
                          {blocking.map((g) => (
                            <p key={g.id} className="text-xs text-negative mt-1">
                              {g.title}: {g.detail}
                            </p>
                          ))}
                          {!t.state && (
                            <input
                              className="input mt-2 max-w-[220px]"
                              placeholder="State"
                              value={manualStates[t.cityName.toLowerCase()] ?? ""}
                              onChange={(e) =>
                                setManualStates({ ...manualStates, [t.cityName.toLowerCase()]: e.target.value })
                              }
                            />
                          )}
                          {/* The editor stays open while the operator is still typing a
                              set they recorded by hand. Hiding it the moment the set
                              resolves made the vehicle count impossible to enter. */}
                          {!t.alreadyExists &&
                            (!t.productSet || Boolean(manualSets[t.cityName.toLowerCase()]?.productSetId?.trim())) && (
                            <div className="mt-2">
                              <p className="text-xs text-ink-500 mb-1.5">
                                {t.productSet
                                  ? "Recorded by hand — correct it here if anything is wrong:"
                                  : `Create it in ${catalogue?.catalogueName ?? "the catalogue"} with that filter, then record it:`}
                              </p>
                              <div className="grid grid-cols-3 gap-2 max-w-[440px]">
                                <input
                                  className="input !py-1.5 !text-xs"
                                  placeholder="Set ID"
                                  value={manualSets[t.cityName.toLowerCase()]?.productSetId ?? ""}
                                  onChange={(e) =>
                                    setManualSets({
                                      ...manualSets,
                                      [t.cityName.toLowerCase()]: {
                                        ...(manualSets[t.cityName.toLowerCase()] ?? { name: "", productCount: 0 }),
                                        productSetId: e.target.value,
                                      },
                                    })
                                  }
                                />
                                <input
                                  className="input !py-1.5 !text-xs"
                                  placeholder={`${t.cityName} Catalogue`}
                                  value={manualSets[t.cityName.toLowerCase()]?.name ?? ""}
                                  onChange={(e) =>
                                    setManualSets({
                                      ...manualSets,
                                      [t.cityName.toLowerCase()]: {
                                        ...(manualSets[t.cityName.toLowerCase()] ?? { productSetId: "", productCount: 0 }),
                                        name: e.target.value,
                                      },
                                    })
                                  }
                                />
                                <input
                                  className="input !py-1.5 !text-xs"
                                  type="number"
                                  placeholder="Vehicles"
                                  value={manualSets[t.cityName.toLowerCase()]?.productCount || ""}
                                  onChange={(e) =>
                                    setManualSets({
                                      ...manualSets,
                                      [t.cityName.toLowerCase()]: {
                                        ...(manualSets[t.cityName.toLowerCase()] ?? { productSetId: "", name: "" }),
                                        productCount: Number(e.target.value) || 0,
                                      },
                                    })
                                  }
                                />
                              </div>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => setCityNames(cityNames.filter((c) => c !== t.cityName))}
                          className="btn-ghost !px-1.5 !py-1 shrink-0"
                          title="Remove"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="label">Daily budget per city</label>
                {/* Free text, not a stepper. `Number(v) || 0` used to turn a
                    cleared field into a hard 0, which then read as a blocking
                    ₹0/day budget the operator never typed. Empty now simply
                    falls back to the source's own figure. */}
                <input
                  type="text"
                  inputMode="numeric"
                  className="input"
                  value={budgetRaw}
                  placeholder={String(source.dailyBudget)}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^\d.]/g, "");
                    setBudgetRaw(v);
                    setBudgetOverride(v === "" ? null : Number(v));
                  }}
                />
                <p className="text-xs text-ink-500 mt-1">From the source: {inr(source.dailyBudget)}</p>
              </div>
              <div>
                <label className="label">CPL ceiling</label>
                <input
                  type="text"
                  inputMode="numeric"
                  className="input"
                  value={ceilingRaw}
                  placeholder={String(source.targetCpl)}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^\d.]/g, "");
                    setCeilingRaw(v);
                    setCeilingOverride(v === "" ? null : Number(v));
                  }}
                />
                <p className="text-xs text-ink-500 mt-1">From the source: {inr(source.targetCpl)}</p>
              </div>
            </div>
          </div>
        )}

        {/* ------------------------------------------------ 2. Review */}
        {step === 2 && plan && source && (
          <div>
            <h2 className="font-bold text-ink-900 dark:text-ink-50 mb-1">Review</h2>
            <p className="text-sm text-ink-500 mb-4">
              {plan.launchable.length} of {plan.targets.length} cities will launch,{" "}
              {inr(plan.totalDailyBudget)}/day in total.
            </p>

            <label className="flex items-start gap-3 p-4 rounded-xl border border-ink-200 dark:border-ink-800 mb-4 cursor-pointer">
              <input
                type="checkbox"
                className="mt-1 accent-brand-600"
                checked={pixelVerified}
                onChange={(e) => setPixelVerified(e.target.checked)}
              />
              <span>
                <span className="block font-semibold text-sm text-ink-900 dark:text-ink-50">
                  A test lead was recorded for every city in this batch
                </span>
                <span className="block text-xs text-ink-500 mt-0.5">
                  Replicating multiplies an untracked pixel across every city at once.
                </span>
              </span>
            </label>

            <div className="rounded-xl border border-ink-200 dark:border-ink-800 overflow-hidden">
              {plan.targets.map((t) => (
                <div
                  key={t.cityName}
                  className="p-3.5 border-b border-ink-200 dark:border-ink-800 last:border-0 flex items-start justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-sm text-ink-900 dark:text-ink-50">
                      {t.cityName}
                      <span className="ml-2 text-xs font-normal text-ink-500">{t.state}</span>
                    </p>
                    <p className="text-xs text-ink-500 mt-0.5">
                      {source.adSets.length} ad set{source.adSets.length === 1 ? "" : "s"} ·{" "}
                      {t.productSet ? `${t.productSet.name} (${num(t.productSet.productCount)})` : "no product set"}
                    </p>
                    {t.plan.gates
                      .filter((g) => g.status !== "PASS")
                      .map((g) => (
                        <p
                          key={g.id}
                          className={cn("text-xs mt-1", g.status === "BLOCK" ? "text-negative" : "text-caution")}
                        >
                          {g.title}: {g.detail}
                        </p>
                      ))}

                    {/* A city you already run cannot be replicated into — that
                        guard is what stops two of your own campaigns bidding
                        against each other. But publishing one deliberately is a
                        different decision, made on a different screen, so point
                        there rather than leaving a wall. */}
                    {t.alreadyExists && (
                      <div className="mt-2.5 pt-2.5 border-t border-ink-200 dark:border-ink-800">
                        <p className="text-xs text-ink-500 mb-2">
                          Replicating into a city you already run would put two of your campaigns in the same
                          auction. Publishing one on purpose — a test, or a deliberate second structure — is a
                          separate decision:
                        </p>
                        <button
                          className="btn-secondary btn-sm !text-xs"
                          onClick={() =>
                            router.push(
                              `/campaigns/publish?city=${encodeURIComponent(t.cityName)}&source=${encodeURIComponent(
                                sourceId
                              )}`
                            )
                          }
                        >
                          <Send className="h-3.5 w-3.5" /> Publish {t.cityName} to Meta instead
                        </button>
                      </div>
                    )}

                    {/* A blocked city used to be a dead end here: the problem was
                        stated on a screen with no way to fix it. The remedy now
                        sits next to the message. */}
                    {!t.alreadyExists &&
                      (!t.productSet ||
                        Boolean(manualSets[t.cityName.toLowerCase()]?.productSetId?.trim())) && (
                      <div className="mt-2.5 pt-2.5 border-t border-ink-200 dark:border-ink-800">
                        <p className="text-xs text-ink-500 mb-1.5">
                          {t.productSet
                            ? "Recorded by hand — correct it here if anything is wrong:"
                            : `Create it in the catalogue filtered on ${t.expectedFilterRule}, or record one you already made:`}
                        </p>
                        <div className="grid grid-cols-3 gap-2 max-w-[440px]">
                          <input
                            className="input !py-1.5 !text-xs"
                            placeholder="Set ID"
                            value={manualSets[t.cityName.toLowerCase()]?.productSetId ?? ""}
                            onChange={(e) =>
                              setManualSets({
                                ...manualSets,
                                [t.cityName.toLowerCase()]: {
                                  ...(manualSets[t.cityName.toLowerCase()] ?? { name: "", productCount: 0 }),
                                  productSetId: e.target.value,
                                },
                              })
                            }
                          />
                          <input
                            className="input !py-1.5 !text-xs"
                            placeholder={`${t.cityName} Catalogue`}
                            value={manualSets[t.cityName.toLowerCase()]?.name ?? ""}
                            onChange={(e) =>
                              setManualSets({
                                ...manualSets,
                                [t.cityName.toLowerCase()]: {
                                  ...(manualSets[t.cityName.toLowerCase()] ?? { productSetId: "", productCount: 0 }),
                                  name: e.target.value,
                                },
                              })
                            }
                          />
                          <input
                            className="input !py-1.5 !text-xs"
                            type="number"
                            placeholder="Vehicles"
                            value={manualSets[t.cityName.toLowerCase()]?.productCount || ""}
                            onChange={(e) =>
                              setManualSets({
                                ...manualSets,
                                [t.cityName.toLowerCase()]: {
                                  ...(manualSets[t.cityName.toLowerCase()] ?? { productSetId: "", name: "" }),
                                  productCount: Number(e.target.value) || 0,
                                },
                              })
                            }
                          />
                        </div>
                        <button
                          className="btn-secondary btn-sm mt-2 !text-xs"
                          disabled={creatingSet === t.cityName}
                          onClick={() => createProductSet(t.cityName)}
                        >
                          {creatingSet === t.cityName ? "Creating…" : "Create it in the catalogue"}
                        </button>
                        {setErrors[t.cityName.toLowerCase()] && (
                          <p className="text-xs text-caution mt-1.5">{setErrors[t.cityName.toLowerCase()]}</p>
                        )}
                      </div>
                    )}
                  </div>
                  <span
                    className={cn(
                      "text-[0.65rem] font-mono uppercase tracking-wide shrink-0 pt-1",
                      t.alreadyExists || !t.plan.canLaunch ? "text-negative" : "text-positive"
                    )}
                  >
                    {t.alreadyExists ? "exists" : t.plan.canLaunch ? "ready" : "blocked"}
                  </span>
                </div>
              ))}
            </div>

            <p className="mt-4 text-xs text-ink-500">
              This prepares the cities in the platform. It does not create anything in Meta — publish each city
              from <span className="font-semibold">Publish to Meta</span> when you are ready for it to go live.
            </p>

            {error && (
              <p className="mt-4 text-sm text-negative flex items-center gap-1.5">
                <CircleAlert className="h-4 w-4" /> {error}
              </p>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between mt-4">
        <button
          onClick={() => (step === 0 ? router.push("/campaigns") : setStep(step - 1))}
          className="btn-secondary"
        >
          <ChevronLeft className="h-4 w-4" /> {step === 0 ? "Cancel" : "Back"}
        </button>
        {step < 2 ? (
          <button
            onClick={() => setStep(step + 1)}
            disabled={step === 0 ? !sourceId : cityNames.length === 0}
            className="btn-primary disabled:opacity-40"
          >
            Continue <ChevronRight className="h-4 w-4" />
          </button>
        ) : (
          <button
            onClick={run}
            disabled={busy || !plan || plan.launchable.length === 0}
            className="btn-primary disabled:opacity-40"
          >
            <Copy className="h-4 w-4" />
            {busy
              ? "Preparing…"
              : `Prepare ${plan?.launchable.length ?? 0} ${plan?.launchable.length === 1 ? "city" : "cities"}`}
          </button>
        )}
      </div>
    </div>
  );
}
