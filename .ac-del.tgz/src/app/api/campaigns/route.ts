import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { campaigns, campaignCities, namingConvention } from "@/lib/db/schema";
import { newId } from "@/lib/id";
import { requireSession, requireEditor } from "@/lib/api-auth";
import { getCampaignMetrics, getCityMetrics } from "@/lib/queries";
import { recommendCampaignStructure } from "@/lib/engine/budget";
import { generateCampaignName } from "@/lib/engine/naming";

export async function GET(req: Request) {
  const { error } = await requireSession();
  if (error) return error;

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");
  const city = searchParams.get("city");
  const search = searchParams.get("search")?.toLowerCase();
  const window = searchParams.get("window") === "7d" ? "7d" : "30d";

  let rows = await getCampaignMetrics(window);
  if (status) rows = rows.filter((c) => c.status === status);
  if (city) rows = rows.filter((c) => c.cities.includes(city));
  if (search) rows = rows.filter((c) => c.name.toLowerCase().includes(search));

  return NextResponse.json({ campaigns: rows });
}

export async function POST(req: Request) {
  const { error } = await requireEditor();
  if (error) return error;

  const body = await req.json();
  const { objective, cityIds, dailyBudget, totalBudget, targetCpl, audienceType, inventoryFilter } = body;

  if (!objective || !Array.isArray(cityIds) || cityIds.length === 0 || !dailyBudget || !targetCpl || !audienceType) {
    return NextResponse.json({ error: "Missing required campaign fields." }, { status: 400 });
  }

  const [allCities, naming] = await Promise.all([
    getCityMetrics(),
    db.query.namingConvention.findFirst({ where: eq(namingConvention.id, "singleton") }),
  ]);
  const selectedCities = allCities.filter((c) => cityIds.includes(c.cityId));
  const totalInventory = selectedCities.reduce((s, c) => s + c.inventoryTotal, 0);
  const structure = recommendCampaignStructure(totalInventory);
  const template = naming?.template ?? "UC | META | {OBJECTIVE} | {CITY} | CATALOGUE | {AUDIENCE}";
  const cityLabel = selectedCities.length === 1 ? selectedCities[0].cityName : `${selectedCities[0]?.cityName ?? "MULTI"}-CLUSTER`;
  const name = generateCampaignName(template, { objective, cityLabel, audience: audienceType });

  const campaignId = newId("camp");
  await db.insert(campaigns).values({
    id: campaignId,
    name,
    objective,
    status: "ACTIVE",
    structureType: structure.structureType,
    audienceType,
    inventoryFilter: JSON.stringify(inventoryFilter ?? { type: "ALL_INVENTORY" }),
    dailyBudget,
    totalBudget: totalBudget ?? dailyBudget * 30,
    targetCpl,
  });

  const inventoryWeightTotal = selectedCities.reduce((s, c) => s + c.inventoryActive, 0) || 1;
  for (const city of selectedCities) {
    await db.insert(campaignCities).values({
      id: newId("cc"),
      campaignId,
      cityId: city.cityId,
      budgetShare: city.inventoryActive / inventoryWeightTotal,
    });
  }

  return NextResponse.json({
    campaign: { id: campaignId, name, structureType: structure.structureType, structureExplanation: structure.explanation },
  });
}
