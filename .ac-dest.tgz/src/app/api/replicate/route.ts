import { NextResponse } from "next/server";
import { db } from "@/lib/db/client";
import { adSets as adSetsTable, campaigns, campaignCities, cities } from "@/lib/db/schema";
import { newId } from "@/lib/id";
import { requireSession, requireEditor } from "@/lib/api-auth";
import { getAdSetSettings, getCampaignMetrics, getCityMetrics } from "@/lib/queries";
import { buildReplicationPlan, describeSource } from "@/lib/engine/replicate";
import { LAUNCH_CONSTANTS, pvAudienceName } from "@/lib/engine/launch";
import {
  DEFAULT_CATALOGUE_ID,
  REAL_CATALOGUES,
  REAL_PRODUCT_SETS,
} from "../../../../scripts/real-catalogue-data";
import { INDIA_CITIES, lookupCity } from "../../../../scripts/india-cities";
import { ACCOUNT, KNOWN_GEO_KEYS } from "../../../../scripts/verified-account-facts";
import { localBlueprint, readBlueprint } from "@/lib/meta/blueprint";
import { buildPublishPlan, executePlan } from "@/lib/meta/publish";
import { searchCity } from "@/lib/meta/graph";

/** Campaigns that can be used as a replication source, with their ad set shapes. */
export async function GET() {
  const { error } = await requireSession();
  if (error) return error;

  const [campaignRows, settings, cityRows] = await Promise.all([
    getCampaignMetrics("30d"),
    getAdSetSettings(),
    getCityMetrics(),
  ]);

  const byCampaign = new Map<string, typeof settings>();
  const adSetRows = await db.select().from(adSetsTable);
  const campaignIdByAdSet = new Map(adSetRows.map((a) => [a.id, a.campaignId]));
  for (const s of settings) {
    const cid = campaignIdByAdSet.get(s.adSetId);
    if (!cid) continue;
    const bucket = byCampaign.get(cid);
    if (bucket) bucket.push(s);
    else byCampaign.set(cid, [s]);
  }

  const sources = campaignRows
    .map((c) => describeSource(c, byCampaign.get(c.campaignId) ?? []))
    .filter((s) => s.adSets.length > 0);

  return NextResponse.json({
    sources,
    catalogues: REAL_CATALOGUES,
    productSets: REAL_PRODUCT_SETS,
    defaultCatalogueId: DEFAULT_CATALOGUE_ID,
    knownCities: INDIA_CITIES,
    existingCityNames: cityRows.map((c) => c.cityName),
    adSetSettings: settings,
  });
}

interface ReplicateBody {
  sourceCampaignId: string;
  cityNames: string[];
  dailyBudget: number;
  cplCeiling: number;
  pixelVerified: boolean;
  catalogueId?: string | null;
  manualStates?: Record<string, string>;
  manualProductSets?: Record<string, { productSetId: string; name: string; productCount: number }>;
  /**
   * Where the batch goes.
   *   PLATFORM — write the plan locally, touch nothing in Meta.
   *   META     — create it in the ad account for real.
   * Defaulting to PLATFORM keeps the old behaviour for anything that does not
   * ask, which matters because the difference is real money.
   */
  destination?: "PLATFORM" | "META";
  /** Only read when destination is META. Paused is the safe default. */
  activate?: boolean;
}

/** True only when live publishing is deliberately switched on AND credentialed. */
function liveReady(): { ok: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (process.env.USE_MOCK_META !== "false") reasons.push("USE_MOCK_META is not set to false.");
  if (!process.env.META_ACCESS_TOKEN?.trim()) reasons.push("META_ACCESS_TOKEN is not set.");
  return { ok: reasons.length === 0, reasons };
}

/**
 * Replicate one campaign into several cities.
 *
 * The gates run again here, per city, and a city that fails is skipped rather
 * than created — a partial success is reported honestly instead of the whole
 * batch failing or, worse, half-creating.
 */
export async function POST(req: Request) {
  const { error } = await requireEditor();
  if (error) return error;

  const body = (await req.json()) as ReplicateBody;
  if (!body.sourceCampaignId || !Array.isArray(body.cityNames) || body.cityNames.length === 0) {
    return NextResponse.json({ error: "Pick a source campaign and at least one city." }, { status: 400 });
  }

  const [campaignRows, settings, cityRows] = await Promise.all([
    getCampaignMetrics("30d"),
    getAdSetSettings(),
    getCityMetrics(),
  ]);

  const sourceCampaign = campaignRows.find((c) => c.campaignId === body.sourceCampaignId);
  if (!sourceCampaign) return NextResponse.json({ error: "Source campaign not found." }, { status: 404 });

  const adSetRows = await db.select().from(adSetsTable);
  const sourceAdSetIds = new Set(adSetRows.filter((a) => a.campaignId === body.sourceCampaignId).map((a) => a.id));
  const sourceSettings = settings.filter((s) => sourceAdSetIds.has(s.adSetId));
  const source = describeSource(sourceCampaign, sourceSettings);

  const catalogueId = body.catalogueId ?? source.catalogueId ?? DEFAULT_CATALOGUE_ID;
  const catalogueRow = REAL_CATALOGUES.find((c) => c.catalogueId === catalogueId) ?? null;

  const plan = buildReplicationPlan({
    source,
    cityNames: body.cityNames,
    dailyBudget: Number(body.dailyBudget) || source.dailyBudget,
    cplCeiling: Number(body.cplCeiling) || source.targetCpl,
    pixelVerified: Boolean(body.pixelVerified),
    existingCityNames: cityRows.map((c) => c.cityName),
    existingAdSets: settings,
    catalogue: catalogueRow
      ? {
          catalogueId: catalogueRow.catalogueId,
          catalogueName: catalogueRow.name,
          vertical: catalogueRow.vertical,
          inUse: catalogueRow.inUse,
        }
      : null,
    productSets: REAL_PRODUCT_SETS,
    manualStates: body.manualStates,
    manualProductSets: body.manualProductSets,
  });

  if (plan.launchable.length === 0) {
    return NextResponse.json(
      { error: "No city in this batch can be launched.", plan },
      { status: 422 }
    );
  }

  const created: {
    cityName: string;
    campaignId: string;
    campaignName: string;
    adSets: { id: string; name: string; kind: string; productSetName: string | null; productCount: number }[];
    pvAudience: string;
    /** Set when the campaign was actually created in the ad account. */
    meta?: { campaignId: string; adSetId?: string; adId?: string; audienceId?: string; status: string };
  }[] = [];

  const perCityBudget = Number(body.dailyBudget) || source.dailyBudget;
  const ceiling = Number(body.cplCeiling) || source.targetCpl;

  // ---------------------------------------------------------------- Meta path
  const toMeta = body.destination === "META";
  const live = liveReady();
  const metaFailures: { cityName: string; error: string; rolledBack: string[] }[] = [];
  const metaResults = new Map<string, { campaignId: string; adSetId?: string; adId?: string; audienceId?: string }>();

  if (toMeta) {
    if (!live.ok) {
      return NextResponse.json(
        { error: `Cannot create in Meta. ${live.reasons.join(" ")}`, plan },
        { status: 409 }
      );
    }
    const cap = Number(process.env.META_MAX_DAILY_BUDGET ?? 5000);
    if (perCityBudget > cap) {
      return NextResponse.json(
        {
          error: `₹${perCityBudget.toLocaleString("en-IN")}/day per city exceeds the ₹${cap.toLocaleString("en-IN")}/day safety cap.`,
        },
        { status: 422 }
      );
    }

    const adAccountId = process.env.META_AD_ACCOUNT_ID?.trim() || ACCOUNT.adAccountId;
    // Settings come from the source campaign as it exists in the account, not
    // from our record of it — that is what "takes every setting from an
    // existing campaign" has to mean once this is real.
    const blueprint = await readBlueprint(body.sourceCampaignId).catch(() =>
      localBlueprint({
        campaignId: sourceCampaign.campaignId,
        name: sourceCampaign.name,
        dailyBudget: sourceCampaign.dailyBudget,
      })
    );

    for (const target of plan.launchable) {
      try {
        // Meta targets cities by numeric key. An ambiguous name is refused
        // rather than resolved — two Aurangabads is a campaign in the wrong
        // state, discovered a week later.
        let geoKey = KNOWN_GEO_KEYS[target.cityName.toLowerCase()] ?? "";
        if (!geoKey) {
          const matches = await searchCity(target.cityName);
          const exact = matches.filter((m) => m.name.toLowerCase() === target.cityName.toLowerCase());
          if (exact.length === 1) geoKey = exact[0].key;
          else if (exact.length > 1 && target.state) {
            const byState = exact.filter((m) => m.region.toLowerCase() === target.state!.toLowerCase());
            if (byState.length === 1) geoKey = byState[0].key;
          }
          if (!geoKey) {
            metaFailures.push({
              cityName: target.cityName,
              error:
                exact.length > 1
                  ? `"${target.cityName}" matches ${exact.length} Indian cities on Meta. Publish it on its own from Publish to Meta, where you can pick which.`
                  : `Meta has no city called "${target.cityName}".`,
              rolledBack: [],
            });
            continue;
          }
        }

        const publishPlan = buildPublishPlan(
          adAccountId,
          blueprint,
          {
            cityName: target.cityName,
            geoKey,
            productSetId: target.productSet?.productSetId ?? "",
            productCount: target.productSet?.productCount ?? 0,
            dailyBudget: perCityBudget,
            cplCeiling: ceiling,
            existingPvAudienceId: null,
          },
          { activate: Boolean(body.activate), mode: "LIVE" }
        );
        const res = await executePlan(publishPlan, "LIVE");
        if (!res.ok || !res.created.campaignId) {
          metaFailures.push({
            cityName: target.cityName,
            error: res.error ?? "Publish failed.",
            rolledBack: res.rolledBack,
          });
          continue;
        }
        metaResults.set(target.cityName, {
          campaignId: res.created.campaignId,
          adSetId: res.created.adSetId,
          adId: res.created.adId,
          audienceId: res.created.audienceId,
        });
      } catch (err) {
        metaFailures.push({
          cityName: target.cityName,
          error: err instanceof Error ? err.message : String(err),
          rolledBack: [],
        });
      }
    }
  }

  for (const target of plan.launchable) {
    // A city Meta refused is not recorded locally either. A local row for a
    // campaign that does not exist is exactly the confusion this whole screen
    // was built to remove.
    if (toMeta && !metaResults.has(target.cityName)) continue;
    const known = lookupCity(target.cityName);
    const cityId = newId("city");
    await db.insert(cities).values({
      id: cityId,
      name: target.cityName,
      state: target.state ?? "Unknown",
      tier: known?.tier ?? "Tier 2",
      status: "HEALTHY",
      dailyBudget: perCityBudget,
      recommendedBudget: perCityBudget,
      targetCpl: ceiling,
    });

    // When it went to Meta, the Meta id IS the local id — the same way every
    // real campaign in this database is keyed. That keeps one campaign as one
    // row rather than a local copy shadowing a remote original.
    const metaOut = metaResults.get(target.cityName);
    const campaignId = metaOut?.campaignId ?? newId("camp");
    await db.insert(campaigns).values({
      id: campaignId,
      name: `UC | META | LEAD | ${target.cityName.toUpperCase()} | CATALOGUE | LAUNCH`,
      objective: "WEBSITE_LEADS",
      status: toMeta && !body.activate ? "PAUSED" : "ACTIVE",
      structureType: "DEDICATED_CITY",
      audienceType: source.adSets.some((a) => a.kind === "REMARKETING") ? "RETARGETING" : "BROAD",
      inventoryFilter: JSON.stringify({ type: "ALL_INVENTORY", cities: [target.cityName] }),
      catalogueName: catalogueRow?.name ?? "",
      dailyBudget: perCityBudget,
      totalBudget: perCityBudget * 30,
      targetCpl: ceiling,
    });
    await db.insert(campaignCities).values({ id: newId("cc"), campaignId, cityId, budgetShare: 1 });

    const perAdSet = Math.floor(perCityBudget / Math.max(1, source.adSets.length));
    const madeAdSets: { id: string; name: string; kind: string; productSetName: string | null; productCount: number }[] = [];

    for (const template of source.adSets) {
      const id = metaOut?.adSetId && template === source.adSets[0] ? metaOut.adSetId : newId("adset");
      // Remarketing is re-pointed at the NEW city's own page-visitor audience.
      // Copying the source city's would advertise Nashik cars to Lucknow.
      const customAudiences = template.kind === "REMARKETING" ? [pvAudienceName(target.cityName)] : [];
      await db.insert(adSetsTable).values({
        id,
        campaignId,
        cityId,
        name: `${target.cityName} · ${template.kind === "BROAD" ? "Broad" : template.kind === "LOOKALIKE" ? "Lookalike" : "Remarketing"}`,
        status: "ACTIVE",
        optimizationGoal: LAUNCH_CONSTANTS.optimizationGoal,
        resultType: source.resultType,
        attributionSetting: source.attributionSetting,
        // Geo is replaced, not copied — copying it is what creates the
        // self-competition the geo audit exists to catch.
        geoCities: JSON.stringify([target.cityName]),
        geoRegions: JSON.stringify([]),
        customAudiences: JSON.stringify(customAudiences),
        excludedAudiences: JSON.stringify([]),
        lookalikeSource: template.lookalikeSource,
        catalogueId: catalogueRow?.catalogueId ?? null,
        catalogueName: catalogueRow?.name ?? null,
        // Re-resolved per city, never inherited.
        productSetId: target.productSet?.productSetId ?? null,
        productSetName: target.productSet?.name ?? null,
        productSetFilter: target.productSet?.filterRule ?? null,
        productCount: target.productSet?.productCount ?? 0,
        interests: JSON.stringify(template.interests),
        ageMin: template.ageMin,
        ageMax: template.ageMax,
        genders: JSON.stringify(template.genders),
        advantageAudience: template.advantageAudience,
        targetingOptimization: LAUNCH_CONSTANTS.targetingOptimization,
        dailyBudget: perAdSet,
        startedAt: new Date(),
      });
      madeAdSets.push({
        id,
        name: `${target.cityName} · ${template.kind}`,
        kind: template.kind,
        productSetName: target.productSet?.name ?? null,
        productCount: target.productSet?.productCount ?? 0,
      });
    }

    created.push({
      cityName: target.cityName,
      campaignId,
      campaignName: `UC | META | LEAD | ${target.cityName.toUpperCase()} | CATALOGUE | LAUNCH`,
      adSets: madeAdSets,
      pvAudience: pvAudienceName(target.cityName),
      meta: metaOut
        ? { ...metaOut, status: body.activate ? "ACTIVE" : "PAUSED" }
        : undefined,
    });
  }

  return NextResponse.json({
    destination: toMeta ? "META" : "PLATFORM",
    activated: toMeta ? Boolean(body.activate) : false,
    // Cities Meta refused are reported separately from cities the gates
    // stopped — they are different problems with different fixes.
    metaFailures,
    created,
    skipped: plan.blocked.map((b) => ({
      cityName: b.cityName,
      reason: b.alreadyExists
        ? "Already in the platform."
        : b.plan.gates.find((g) => g.status === "BLOCK")?.detail ?? "Blocked.",
    })),
    source: { campaignId: source.campaignId, name: source.name },
    totalDailyBudget: created.length * perCityBudget,
  });
}
