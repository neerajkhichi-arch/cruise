/**
 * The thinnest possible Graph API layer.
 *
 * Two rules here, both learned the hard way from the way Meta reports errors:
 *
 *   1. A Graph error arrives as HTTP 400 with a JSON body that says what is
 *      actually wrong. Throwing "Request failed with status 400" destroys the
 *      only useful information in the response, so `GraphError` carries the
 *      message, type, code, subcode and `error_user_msg` through untouched.
 *
 *   2. Every write is logged before it is sent, in the exact shape it is sent.
 *      A campaign that appears in Ads Manager and nowhere in our records is a
 *      campaign nobody can explain later.
 */

const GRAPH_VERSION = "v21.0";
const GRAPH_BASE = `https://graph.facebook.com/${GRAPH_VERSION}`;

export class GraphError extends Error {
  readonly type: string;
  readonly code: number;
  readonly subcode: number | null;
  /** Meta's own user-facing wording, which is usually the actionable part. */
  readonly userMessage: string | null;
  readonly userTitle: string | null;
  readonly path: string;
  readonly payload: Record<string, unknown>;

  constructor(
    path: string,
    payload: Record<string, unknown>,
    body: {
      message?: string;
      type?: string;
      code?: number;
      error_subcode?: number;
      error_user_msg?: string;
      error_user_title?: string;
    }
  ) {
    super(body.error_user_msg || body.message || "Graph API call failed");
    this.name = "GraphError";
    this.type = body.type ?? "unknown";
    this.code = body.code ?? 0;
    this.subcode = body.error_subcode ?? null;
    this.userMessage = body.error_user_msg ?? null;
    this.userTitle = body.error_user_title ?? null;
    this.path = path;
    this.payload = payload;
  }

  /** What to show an operator: Meta's wording, plus which call failed. */
  describe(): string {
    const where = `${this.path} (code ${this.code}${this.subcode ? `/${this.subcode}` : ""})`;
    return this.userTitle ? `${this.userTitle}: ${this.message} — ${where}` : `${this.message} — ${where}`;
  }
}

export interface GraphCall {
  /** Ordinal within a publish run, so a failure names the step that failed. */
  step: number;
  label: string;
  method: "GET" | "POST" | "DELETE";
  path: string;
  payload: Record<string, unknown>;
  /**
   * A step the launch can survive without. The page-visitor audience is the
   * case: it is preparation for day 30, not something the campaign needs in
   * order to run, so failing to create it should not take the campaign down
   * with it.
   */
  optional?: boolean;
}

export interface GraphCallResult extends GraphCall {
  status: "OK" | "FAILED" | "SKIPPED";
  /** The id Meta assigned, when the call created something. */
  id?: string;
  error?: string;
  /** True when this ran against the API; false for a dry run. */
  sent: boolean;
}

function token(): string {
  const t = process.env.META_ACCESS_TOKEN?.trim();
  if (!t) {
    throw new Error(
      "META_ACCESS_TOKEN is not set. Live publishing needs a system user token with ads_management on the ad account."
    );
  }
  return t;
}

/**
 * Graph expects nested objects as JSON strings in a form body, not as JSON.
 * Getting this wrong produces "param targeting must be an object", which is
 * an unhelpful way of saying "you sent an object where a string was wanted".
 */
export function encodeParams(payload: Record<string, unknown>): URLSearchParams {
  const form = new URLSearchParams();
  for (const [key, value] of Object.entries(payload)) {
    if (value === undefined || value === null) continue;
    form.set(key, typeof value === "object" ? JSON.stringify(value) : String(value));
  }
  return form;
}

export async function graphPost<T = { id: string }>(
  path: string,
  payload: Record<string, unknown>
): Promise<T> {
  const form = encodeParams(payload);
  form.set("access_token", token());

  const res = await fetch(`${GRAPH_BASE}/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  });

  const body = (await res.json().catch(() => ({}))) as Record<string, unknown> & {
    error?: ConstructorParameters<typeof GraphError>[2];
  };
  if (!res.ok || body.error) {
    throw new GraphError(path, payload, body.error ?? { message: `HTTP ${res.status}` });
  }
  return body as T;
}

export async function graphGet<T = Record<string, unknown>>(
  path: string,
  params: Record<string, string> = {}
): Promise<T> {
  const qs = new URLSearchParams({ ...params, access_token: token() });
  const res = await fetch(`${GRAPH_BASE}/${path}?${qs.toString()}`);
  const body = (await res.json().catch(() => ({}))) as Record<string, unknown> & {
    error?: ConstructorParameters<typeof GraphError>[2];
  };
  if (!res.ok || body.error) {
    throw new GraphError(path, params, body.error ?? { message: `HTTP ${res.status}` });
  }
  return body as T;
}

export async function graphDelete(path: string): Promise<void> {
  const qs = new URLSearchParams({ access_token: token() });
  const res = await fetch(`${GRAPH_BASE}/${path}?${qs.toString()}`, { method: "DELETE" });
  const body = (await res.json().catch(() => ({}))) as { error?: ConstructorParameters<typeof GraphError>[2] };
  if (!res.ok || body.error) {
    throw new GraphError(path, {}, body.error ?? { message: `HTTP ${res.status}` });
  }
}

/** `act_` prefix, added once and only once. */
export function actPath(adAccountId: string, edge: string): string {
  const id = adAccountId.startsWith("act_") ? adAccountId : `act_${adAccountId}`;
  return `${id}/${edge}`;
}

// ---------------------------------------------------------------------------
// Geo resolution
// ---------------------------------------------------------------------------

export interface GeoCity {
  key: string;
  name: string;
  region: string;
  country: string;
}

/**
 * Meta targets cities by its own numeric key, never by name — the live ad sets
 * carry `{"key":1015741,"name":"Ahmedabad"}`. Our model stores the name the
 * operator typed, so a launch has to resolve it here or target nothing.
 *
 * Ambiguity is returned rather than resolved: India has more than one
 * Aurangabad, and silently picking the larger one puts a campaign in the wrong
 * state.
 */
export async function searchCity(name: string, country = "IN"): Promise<GeoCity[]> {
  const body = await graphGet<{ data: { key: string; name: string; region?: string; country_code?: string; country_name?: string }[] }>(
    "search",
    { type: "adgeolocation", location_types: '["city"]', q: name, limit: "10" }
  );
  return (body.data ?? [])
    .filter((c) => !country || c.country_code === country)
    .map((c) => ({
      key: String(c.key),
      name: c.name,
      region: c.region ?? "",
      country: c.country_code ?? country,
    }));
}
