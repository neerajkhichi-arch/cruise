/**
 * Turning a launch into Graph API calls, and running them.
 *
 * One builder serves both modes. A dry run returns the call list; a live run
 * executes that same list. There is deliberately no second code path, because
 * a dry run that prints something other than what the live run sends is worse
 * than no dry run at all.
 *
 * Calls are ordered so that each depends only on ids produced before it, and
 * placeholders (`{{campaign_id}}`) are substituted as the run proceeds. On a
 * failure the executor deletes what it has already created, in reverse. A
 * half-built campaign in Ads Manager — a campaign and ad set with no ad, still
 * ACTIVE — is the worst outcome available, and it is the default one if you
 * do not write the rollback.
 */

import { actPath, graphDelete, graphPost, GraphError, type GraphCall, type GraphCallResult } from "./graph";
import type { SourceBlueprint } from "./blueprint";

export interface PublishTarget {
  cityName: string;
  /** Meta's numeric city key, resolved before this point. */
  geoKey: string;
  productSetId: string;
  productCount: number;
  /** Rupees per day, at the campaign (CBO) level. */
  dailyBudget: number;
  cplCeiling: number;
  /** Whether a page-visitor audience for this city already exists. */
  existingPvAudienceId: string | null;
}

export interface PublishPlan {
  target: PublishTarget;
  calls: GraphCall[];
  /** Decisions taken while building, shown to the operator before they commit. */
  notes: string[];
  /** Reasons this cannot be published at all. */
  blockers: string[];
}

const PLACEHOLDER = {
  campaign: "{{campaign_id}}",
  adSet: "{{adset_id}}",
  creative: "{{creative_id}}",
  audience: "{{audience_id}}",
} as const;

/** Meta takes budgets in minor units — paise, not rupees. */
function toMinorUnits(rupees: number): number {
  return Math.round(rupees * 100);
}

function swapCity(text: string | null, from: string | null, to: string): string | null {
  if (!text) return text;
  if (!from) return text;
  return text.replace(new RegExp(from, "gi"), to);
}

export function buildPublishPlan(
  adAccountId: string,
  blueprint: SourceBlueprint,
  target: PublishTarget,
  opts: { activate: boolean; mode: "DRY_RUN" | "LIVE" }
): PublishPlan {
  const calls: GraphCall[] = [];
  const notes: string[] = [];
  const blockers: string[] = [];
  let step = 0;
  const add = (
    label: string,
    path: string,
    payload: Record<string, unknown>,
    optional = false
  ) => {
    calls.push({ step: ++step, label, method: "POST", path, payload, optional });
  };

  // A preview is allowed to be incomplete; a live run is not. Anything the
  // preview cannot know is shown as a placeholder and named in the notes,
  // rather than being quietly filled with something plausible.
  const geoKey = target.geoKey || "<resolved from Meta's city search at publish>";
  if (!target.geoKey) {
    if (opts.mode === "LIVE") {
      blockers.push(
        `No Meta city key for ${target.cityName}. Meta targets cities by numeric key, not by name, so this cannot be created until the name resolves to exactly one city.`
      );
    } else {
      notes.push(
        `Meta targets cities by numeric key, not by name. ${target.cityName}'s key is looked up at publish; if the name matches more than one Indian city the publish stops and asks which.`
      );
    }
  }
  if (!target.productSetId) {
    const msg = `No product set for ${target.cityName}. A catalogue ad draws its creative from the product feed, so there is nothing to serve without one.`;
    if (opts.mode === "LIVE") blockers.push(msg);
    else notes.push(msg + " Create it in Commerce Manager filtered on the city, then record its ID here.");
  } else if (target.productCount === 0) {
    // A product set can exist and match nothing. The campaign is then created
    // successfully, is approved, and serves an empty carousel — the failure is
    // invisible until you wonder why a live campaign has no impressions. So an
    // empty set is refused outright rather than warned about.
    blockers.push(
      `The product set for ${target.cityName} matches 0 vehicles. The campaign would be created and approved, and then serve nothing. Get the city's stock into the catalogue before launching it.`
    );
  }
  if (!blueprint.creative?.pageId) {
    blockers.push("The source ad's creative has no page, so a new ad cannot be built from it.");
  }

  // The conversion event is the one field that fails silently. An ad set with
  // custom_event_type "OTHER" and no custom_event_str is accepted by the API,
  // runs, spends, and optimises for no particular event — and reads as correct
  // everywhere you would look. So it is a refusal, not a warning.
  const promoted = blueprint.adSet.promotedObject as Record<string, unknown>;
  if (promoted.custom_event_type === "OTHER" && !promoted.custom_event_str) {
    blockers.push(
      "The source optimises for a custom pixel event, but the event name is missing. Meta accepts the ad set anyway and it optimises for nothing in particular, so this is refused rather than warned about. Set META_CONVERSION_EVENT."
    );
  } else if (promoted.custom_event_str) {
    notes.push(
      `Optimising for the custom pixel event ${String(promoted.custom_event_str)} on dataset ${String(promoted.pixel_id)} — the same event the source ad set uses.`
    );
  }

  // --- 1. the city's page-visitor audience ---------------------------------
  // The operator chose: create the audience, skip the remarketing ad set. The
  // audience starts empty and fills from today, so it is worth something in a
  // month; an ad set pointed at it today would simply not deliver.
  let audienceRef: string | null = target.existingPvAudienceId;
  if (!audienceRef && blueprint.pvAudience) {
    const { rule, cityField, cityValue, retentionDays } = blueprint.pvAudience;
    if (cityField && cityValue) {
      const newRule = rule.replace(
        new RegExp(`("${cityField}"[^}]*?"value"\\s*:\\s*")${cityValue}(")`, "i"),
        `$1${target.cityName.toLowerCase()}$2`
      );
      if (newRule === rule) {
        notes.push(
          `Could not rewrite the ${cityField} filter in the source audience rule, so no page-visitor audience was created for ${target.cityName}. Create it by hand from the Ahmedabad one.`
        );
      } else {
        // No `subtype`: the current API rejects it outright ("not supported in
        // the current API version"). A rule-based website audience is defined
        // by its rule; the subtype was removed.
        add(
          "Create page-visitor audience",
          actPath(adAccountId, "customaudiences"),
          {
            name: `CD-FB-Buy Used Car-PV-${target.cityName.toLowerCase()}-90Days-New`,
            retention_days: retentionDays,
            rule: newRule,
            prefill: true,
          },
          true // optional — the campaign does not depend on it
        );
        audienceRef = PLACEHOLDER.audience;
        notes.push(
          `Creating the 90-day page-visitor audience for ${target.cityName} now, so it starts filling today. No remarketing ad set is created — it would have nobody to deliver to. Revisit at day 30.`
        );
      }
    } else {
      notes.push(
        `The source's page-visitor audience has no readable city filter, so none was cloned for ${target.cityName}.`
      );
    }
  } else if (audienceRef) {
    notes.push(`${target.cityName} already has a page-visitor audience; reusing it rather than creating a second.`);
  }

  // --- 2. campaign ---------------------------------------------------------
  // Budget sits here, not on the ad set: the source campaigns are CBO.
  const campaignName = `UC | META | LEAD | ${target.cityName.toUpperCase()} | CATALOGUE | LAUNCH`;
  add("Create campaign", actPath(adAccountId, "campaigns"), {
    name: campaignName,
    objective: blueprint.campaign.objective,
    status: opts.activate ? "ACTIVE" : "PAUSED",
    special_ad_categories: [],
    bid_strategy: blueprint.campaign.bidStrategy,
    daily_budget: toMinorUnits(target.dailyBudget),
  });

  // --- 3. ad set -----------------------------------------------------------
  // Everything from the source except geo, which is the whole point.
  const targeting: Record<string, unknown> = {
    ...blueprint.adSet.targetingTemplate,
    geo_locations: {
      cities: [{ key: geoKey, radius: 0, distance_unit: "mile" }],
      location_types: ["home", "recent"],
    },
  };
  add("Create ad set", actPath(adAccountId, "adsets"), {
    name: `${target.cityName} · Broad`,
    campaign_id: PLACEHOLDER.campaign,
    status: opts.activate ? "ACTIVE" : "PAUSED",
    optimization_goal: blueprint.adSet.optimizationGoal,
    billing_event: blueprint.adSet.billingEvent,
    promoted_object: blueprint.adSet.promotedObject,
    targeting,
  });

  // --- 4. creative ---------------------------------------------------------
  const c = blueprint.creative;
  if (c?.pageId) {
    add("Create catalogue creative", actPath(adAccountId, "adcreatives"), {
      name: `${target.cityName} · Catalogue`,
      product_set_id: target.productSetId || "<product set for this city>",
      object_story_spec: {
        page_id: c.pageId,
        ...(c.instagramActorId ? { instagram_actor_id: c.instagramActorId } : {}),
        template_data: {
          // The source's headline is a catalogue token, so it carries across
          // untouched. The body names a city and a vehicle count, so both are
          // rewritten — otherwise Lucknow's ad advertises Mohali's inventory.
          name: c.title ?? "{{vehicle.title}} {{vehicle.price strip_zeros}}",
          message: rewriteBody(c.body, blueprint.adSet.sourceCityName, target),
          link: c.linkUrl ?? "https://www.cardekho.com/used-cars",
          call_to_action: { type: c.callToActionType ?? "GET_QUOTE" },
        },
      },
    });
    add("Create ad", actPath(adAccountId, "ads"), {
      name: `Catalogue-${target.cityName}`,
      adset_id: PLACEHOLDER.adSet,
      creative: { creative_id: PLACEHOLDER.creative },
      status: opts.activate ? "ACTIVE" : "PAUSED",
    });
  }

  if (opts.activate) {
    notes.push(
      `Everything is created ACTIVE, so delivery and spend begin as soon as review passes — up to ₹${target.dailyBudget.toLocaleString("en-IN")} a day for this city.`
    );
  }

  return { target, calls, notes, blockers };
}

/**
 * The source body reads "595+ used cars to choose from in Mohali!". Both halves
 * are wrong for a new city, and the count is the half people forget.
 */
function rewriteBody(body: string | null, sourceCity: string | null, target: PublishTarget): string {
  const fallback = `${target.productCount}+ used cars to choose from in ${target.cityName}! 🚘`;
  if (!body) return fallback;
  let out = swapCity(body, sourceCity, target.cityName) ?? body;
  out = out.replace(/\d[\d,]*\s*\+/, `${target.productCount}+`);
  return out;
}

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

export interface PublishResult {
  cityName: string;
  mode: "DRY_RUN" | "LIVE";
  ok: boolean;
  results: GraphCallResult[];
  created: { campaignId?: string; adSetId?: string; creativeId?: string; adId?: string; audienceId?: string };
  notes: string[];
  error?: string;
  rolledBack: string[];
}

function substitute(payload: Record<string, unknown>, ids: Record<string, string>): Record<string, unknown> {
  const raw = JSON.stringify(payload);
  const filled = raw.replace(/\{\{(campaign_id|adset_id|creative_id|audience_id)\}\}/g, (m, key: string) =>
    ids[key] ?? m
  );
  return JSON.parse(filled) as Record<string, unknown>;
}

export async function executePlan(plan: PublishPlan, mode: "DRY_RUN" | "LIVE"): Promise<PublishResult> {
  const results: GraphCallResult[] = [];
  // Starts from the plan's notes and gains any skipped optional step, so the
  // result explains itself without the caller cross-referencing two lists.
  const notes: string[] = [...plan.notes];
  const ids: Record<string, string> = {};
  const created: PublishResult["created"] = {};
  const rolledBack: string[] = [];

  if (plan.blockers.length > 0) {
    return {
      cityName: plan.target.cityName,
      mode,
      ok: false,
      results: plan.calls.map((c) => ({ ...c, status: "SKIPPED", sent: false })),
      created,
      notes,
      error: plan.blockers.join(" "),
      rolledBack,
    };
  }

  if (mode === "DRY_RUN") {
    return {
      cityName: plan.target.cityName,
      mode,
      ok: true,
      results: plan.calls.map((c) => ({
        ...c,
        payload: substitute(c.payload, {
          campaign_id: "<campaign created in step 2>",
          adset_id: "<ad set created in step 3>",
          creative_id: "<creative created in step 4>",
          audience_id: "<audience created in step 1>",
        }),
        status: "OK",
        sent: false,
      })),
      created,
      notes,
      rolledBack,
    };
  }

  // --- live ---------------------------------------------------------------
  // Track what we make so a later failure can be undone.
  const undo: { path: string; label: string }[] = [];

  for (const call of plan.calls) {
    const payload = substitute(call.payload, ids);
    try {
      const res = await graphPost<{ id: string }>(call.path, payload);
      results.push({ ...call, payload, status: "OK", id: res.id, sent: true });

      if (call.path.endsWith("/campaigns")) {
        ids.campaign_id = res.id;
        created.campaignId = res.id;
      } else if (call.path.endsWith("/adsets")) {
        ids.adset_id = res.id;
        created.adSetId = res.id;
      } else if (call.path.endsWith("/adcreatives")) {
        ids.creative_id = res.id;
        created.creativeId = res.id;
      } else if (call.path.endsWith("/ads")) {
        created.adId = res.id;
      } else if (call.path.endsWith("/customaudiences")) {
        ids.audience_id = res.id;
        created.audienceId = res.id;
      }
      // The audience is deliberately NOT added to the undo list. It costs
      // nothing, harms nothing, and starts filling the moment it exists — so
      // keeping it after a failed launch is strictly better than deleting it.
      if (!call.path.endsWith("/customaudiences")) {
        undo.unshift({ path: res.id, label: call.label });
      }
    } catch (err) {
      const message = err instanceof GraphError ? err.describe() : String(err);
      results.push({ ...call, payload, status: "FAILED", error: message, sent: true });

      // An optional step failing is a note, not a rollback. Losing the
      // page-visitor audience costs a day-30 option; losing the campaign
      // because of it costs the whole launch.
      if (call.optional) {
        notes.push(`${call.label} failed and was skipped — ${message}`);
        continue;
      }

      for (const u of undo) {
        try {
          await graphDelete(u.path);
          rolledBack.push(`${u.label} (${u.path})`);
        } catch {
          rolledBack.push(`FAILED TO REMOVE ${u.label} (${u.path}) — delete it by hand in Ads Manager`);
        }
      }
      return {
        cityName: plan.target.cityName,
        mode,
        ok: false,
        results,
        created: {},
        notes,
        error: message,
        rolledBack,
      };
    }
  }

  return { cityName: plan.target.cityName, mode, ok: true, results, created, notes, rolledBack };
}
