import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { graphGet, GraphError } from "@/lib/meta/graph";
import { ACCOUNT } from "../../../../../scripts/verified-account-facts";
import { DEFAULT_CATALOGUE_ID } from "../../../../../scripts/real-catalogue-data";

/**
 * Does this token actually do what publishing needs?
 *
 * A token can be present and still be wrong in four different ways: expired,
 * missing a scope, not assigned to the ad account, or not assigned to the
 * catalogue. Each of those fails at a different step of a publish, halfway
 * through, which is the worst time to discover it. So every one is checked
 * up front, separately, and reported by name.
 */

interface Check {
  id: string;
  label: string;
  status: "PASS" | "FAIL" | "SKIP";
  detail: string;
  remedy?: string;
}

export async function GET() {
  const { error } = await requireSession();
  if (error) return error;

  const checks: Check[] = [];
  const token = process.env.META_ACCESS_TOKEN?.trim();
  const adAccountId = process.env.META_AD_ACCOUNT_ID?.trim() || ACCOUNT.adAccountId;
  const catalogueId = process.env.META_CATALOGUE_ID?.trim() || DEFAULT_CATALOGUE_ID;

  // --- 1. is there a token at all -----------------------------------------
  if (!token) {
    checks.push({
      id: "token",
      label: "Access token",
      status: "FAIL",
      detail: "META_ACCESS_TOKEN is not set.",
      remedy: "Add it to .env and restart the server.",
    });
    return NextResponse.json({ ok: false, checks, mockMode: process.env.USE_MOCK_META !== "false" });
  }

  // --- 2. is it valid, and what can it do ---------------------------------
  let scopes: string[] = [];
  try {
    const debug = await graphGet<{
      data?: { is_valid?: boolean; scopes?: string[]; expires_at?: number; type?: string; app_id?: string };
    }>("debug_token", { input_token: token });
    const d = debug.data ?? {};
    scopes = d.scopes ?? [];
    const expiresAt = d.expires_at ?? 0;
    const neverExpires = expiresAt === 0;
    const expired = !neverExpires && expiresAt * 1000 < Date.now();

    checks.push({
      id: "token",
      label: "Access token",
      status: d.is_valid && !expired ? "PASS" : "FAIL",
      detail: d.is_valid
        ? expired
          ? `Expired on ${new Date(expiresAt * 1000).toLocaleString("en-IN")}.`
          : neverExpires
          ? "Valid, and does not expire — a system user token."
          : `Valid until ${new Date(expiresAt * 1000).toLocaleString("en-IN")}. A short-lived token is fine for a test and useless for anything scheduled.`
        : "Meta reports this token as invalid.",
      remedy: d.is_valid && !expired ? undefined : "Generate a new token and restart the server.",
    });

    // --- 3. the two scopes that matter ------------------------------------
    for (const [scope, why] of [
      ["ads_management", "creating campaigns, ad sets, creatives and ads"],
      ["catalog_management", "creating a city product set in the catalogue"],
    ] as const) {
      const has = scopes.includes(scope);
      checks.push({
        id: scope,
        label: scope,
        status: has ? "PASS" : "FAIL",
        detail: has ? `Granted — needed for ${why}.` : `Missing. Without it, ${why} will fail.`,
        remedy: has ? undefined : `Re-generate the token with ${scope} ticked.`,
      });
    }
  } catch (err) {
    checks.push({
      id: "token",
      label: "Access token",
      status: "FAIL",
      detail: err instanceof GraphError ? err.describe() : String(err),
      remedy: "The token could not be inspected. It is probably malformed or from a different app.",
    });
  }

  // --- 4. can it reach the ad account -------------------------------------
  try {
    const acct = await graphGet<{ id: string; name: string; currency: string; account_status: number }>(
      `act_${adAccountId}`,
      { fields: "id,name,currency,account_status" }
    );
    checks.push({
      id: "ad_account",
      label: "Ad account",
      status: "PASS",
      detail: `${acct.name} (${acct.id}), ${acct.currency}.`,
    });
  } catch (err) {
    checks.push({
      id: "ad_account",
      label: "Ad account",
      status: "FAIL",
      detail: err instanceof GraphError ? err.describe() : String(err),
      remedy: `The token cannot read ad account ${adAccountId}. Assign the account to the system user in Business Settings.`,
    });
  }

  // --- 5. can it reach the catalogue --------------------------------------
  try {
    const cat = await graphGet<{ id: string; name: string; product_count?: number }>(catalogueId, {
      fields: "id,name,product_count",
    });
    checks.push({
      id: "catalogue",
      label: "Catalogue",
      status: "PASS",
      detail: `${cat.name} (${cat.id})${cat.product_count != null ? `, ${cat.product_count} products` : ""}.`,
    });
  } catch (err) {
    checks.push({
      id: "catalogue",
      label: "Catalogue",
      status: "FAIL",
      detail: err instanceof GraphError ? err.describe() : String(err),
      remedy: `The token cannot read catalogue ${catalogueId}. Assign the catalogue to the system user too — an ad account assignment does not cover it.`,
    });
  }

  // --- 6. is live mode actually switched on -------------------------------
  const mock = process.env.USE_MOCK_META !== "false";
  checks.push({
    id: "live_mode",
    label: "Live mode",
    status: mock ? "FAIL" : "PASS",
    detail: mock
      ? "USE_MOCK_META is not set to false, so publishing stays in preview even with a valid token."
      : "Publishing is armed.",
    remedy: mock ? "Set USE_MOCK_META=false in .env and restart." : undefined,
  });

  return NextResponse.json({
    ok: checks.every((c) => c.status !== "FAIL"),
    checks,
    scopes,
    adAccountId,
    catalogueId,
    mockMode: mock,
  });
}
